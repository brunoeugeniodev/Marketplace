// ========== CARRINHO PAGE - Scripts específicos ==========

document.addEventListener('DOMContentLoaded', function() {
    console.log('Carrinho page - Script carregado');

    // ========== VERIFICAÇÃO DE LOGIN ==========
    const token = localStorage.getItem('jwtToken');
    if (!token) {
        showCartEmptyState('Você precisa estar logado para acessar o carrinho!');

        const loginBtn = document.createElement('a');
        loginBtn.href = '/login?redirect=' + encodeURIComponent('/carrinho');
        loginBtn.className = 'btn btn-primary mt-20';
        loginBtn.innerHTML = '<i class="fas fa-sign-in-alt"></i> Fazer Login';

        document.querySelector('.cart-empty')?.appendChild(loginBtn);
        return;
    }

    // ========== CARREGAR ITENS DO CARRINHO ==========
    async function loadCartItems() {
        try {
            const response = await fetch('/api/carrinho', {
                method: 'GET',
                headers: getAuthHeader()
            });

            if (response.status === 401 || response.status === 403) {
                showCartEmptyState('Sua sessão expirou. Faça login novamente.');

                const loginBtn = document.createElement('a');
                loginBtn.href = '/login?redirect=' + encodeURIComponent('/carrinho');
                loginBtn.className = 'btn btn-primary mt-20';
                loginBtn.innerHTML = '<i class="fas fa-sign-in-alt"></i> Fazer Login';

                document.querySelector('.cart-empty')?.appendChild(loginBtn);
                return;
            }

            if (!response.ok) {
                throw new Error('Erro ao carregar carrinho');
            }

            const data = await response.json();

            if (data?.itens?.length > 0) {
                renderCartItems(data.itens);
                updateCartSummary(data.total);
            } else {
                showCartEmptyState('Seu carrinho está vazio');
            }

        } catch (error) {
            console.error('Erro ao carregar carrinho:', error);
            showCartEmptyState('Erro ao carregar carrinho. Tente novamente mais tarde.');
        }
    }

    // ========== RENDERIZAR ITENS DO CARRINHO ==========
    function renderCartItems(items) {
        const cartItemsContainer = document.querySelector('.cart-items');
        if (!cartItemsContainer) return;

        cartItemsContainer.innerHTML = '';

        items.forEach(item => {
            const cartItemHTML = `
                <div class="cart-item" data-item-id="${item.id}">
                    <img src="${item.produtoFotoUrl || item.produto?.fotoUrl || '/imagens/placeholder.png'}"
                         alt="${item.produtoNome || item.produto?.nome || 'Produto'}"
                         class="cart-item-img">

                    <div class="cart-item-info">
                        <h3>${item.produtoNome || item.produto?.nome}</h3>
                        <p>${item.produtoDescricao || item.produto?.descricao}</p>
                        <div class="cart-item-price">R$ ${item.precoUnitario?.toFixed(2)}</div>

                        <div class="cart-item-quantity">
                            <button class="quantity-btn quantity-minus" data-item-id="${item.id}">-</button>

                            <input type="number"
                                   class="quantity-input"
                                   value="${item.quantidade}"
                                   min="1"
                                   max="${item.produtoQuantidadeDisponivel || item.produto?.quantidade || 99}"
                                   data-item-id="${item.id}">

                            <button class="quantity-btn quantity-plus" data-item-id="${item.id}">+</button>
                        </div>
                    </div>

                    <div class="cart-item-actions">
                        <button class="btn-remove" data-item-id="${item.id}">
                            <i class="fas fa-trash"></i> Remover
                        </button>
                    </div>
                </div>
            `;

            cartItemsContainer.insertAdjacentHTML('beforeend', cartItemHTML);
        });

        addCartItemEvents();
    }

    // ========== MOSTRAR CARRINHO VAZIO ==========
    function showCartEmptyState(message = 'Seu carrinho está vazio') {
        const cartContent = document.querySelector('.cart-content');
        if (!cartContent) return;

        cartContent.innerHTML = `
            <div class="cart-empty">
                <i class="fas fa-shopping-cart"></i>
                <h3>${message}</h3>
                <p>Adicione produtos para ver seus itens aqui.</p>
                <a href="/" class="btn btn-primary mt-20">
                    <i class="fas fa-store"></i> Continuar Comprando
                </a>
            </div>
        `;
    }

    // ========== RESUMO DO CARRINHO ==========
    function updateCartSummary(total) {
        const subtotalElement = document.querySelector('.summary-row:nth-child(1) .value');
        const freteElement = document.querySelector('.summary-row:nth-child(2) .value');
        const totalElement = document.querySelector('.summary-row.total .value');

        if (subtotalElement) subtotalElement.textContent = `R$ ${total?.toFixed(2)}`;
        if (freteElement) freteElement.textContent = 'R$ 0,00';
        if (totalElement) totalElement.textContent = `R$ ${total?.toFixed(2)}`;
    }

    // ========== EVENTOS DOS ITENS ==========
    function addCartItemEvents() {
        // Botões de quantidade
        document.querySelectorAll('.quantity-btn').forEach(button => {
            button.addEventListener('click', function() {
                const itemId = this.dataset.itemId;
                const input = this.closest('.cart-item-quantity').querySelector('.quantity-input');

                let value = parseInt(input.value) || 1;
                const max = parseInt(input.max) || 99;

                if (this.classList.contains('quantity-minus')) {
                    value = Math.max(1, value - 1);
                } else if (this.classList.contains('quantity-plus')) {
                    value = Math.min(max, value + 1);
                }

                input.value = value;
                updateCartItemQuantity(itemId, value);
            });
        });

        // Mudança manual
        document.querySelectorAll('.quantity-input').forEach(input => {
            input.addEventListener('change', function() {
                const value = Math.max(
                    parseInt(this.min) || 1,
                    Math.min(parseInt(this.max) || 99, parseInt(this.value) || 1)
                );

                this.value = value;
                updateCartItemQuantity(this.dataset.itemId, value);
            });
        });

        // Botão remover
        document.querySelectorAll('.btn-remove').forEach(button => {
            button.addEventListener('click', function() {
                removeCartItem(this.dataset.itemId);
            });
        });
    }

    // ========== ATUALIZAR QUANTIDADE ==========
    async function updateCartItemQuantity(itemId, quantidade) {
        try {
            const response = await fetch(`/api/carrinho/itens/${itemId}?quantidade=${quantidade}`, {
                method: 'PUT',
                headers: getAuthHeader()
            });

            if (response.status === 401 || response.status === 403) {
                showNotification('Sessão expirada', 'error');
                return window.location.href = '/login?redirect=/carrinho';
            }

            if (!response.ok) throw new Error();

            const data = await response.json();

            // Atualiza preço
            const cartItem = document.querySelector(`.cart-item[data-item-id="${itemId}"]`);
            if (cartItem) {
                cartItem.querySelector('.cart-item-price').textContent =
                    `R$ ${data.subtotal?.toFixed(2)}`;
            }

            // Atualiza resumo
            updateCartSummary(data.total);

            // Atualiza contador global
            loadCartCount();

        } catch (error) {
            console.error(error);
            showNotification('Erro ao atualizar quantidade', 'error');
        }
    }

    // ========== REMOVER ITEM ==========
    async function removeCartItem(itemId) {
        if (!confirm('Deseja remover este item?')) return;

        try {
            const response = await fetch(`/api/carrinho/itens/${itemId}`, {
                method: 'DELETE',
                headers: getAuthHeader()
            });

            if (response.status === 401 || response.status === 403) {
                showNotification('Sessão expirada', 'error');
                return window.location.href = '/login?redirect=/carrinho';
            }

            if (!response.ok) throw new Error();

            document.querySelector(`.cart-item[data-item-id="${itemId}"]`)?.remove();

            showNotification('Item removido', 'success');
            loadCartCount();

            if (document.querySelectorAll('.cart-item').length === 0) {
                showCartEmptyState();
            }

        } catch (error) {
            console.error(error);
            showNotification('Erro ao remover item', 'error');
        }
    }

    // ========== FINALIZAR COMPRA ==========
    const btnFinalizarCompra = document.getElementById('btn-finalizar-compra');
    if (btnFinalizarCompra) {
        btnFinalizarCompra.addEventListener('click', () => {
            if (!localStorage.getItem('jwtToken')) {
                showNotification('Você precisa estar logado!', 'error');
                return window.location.href = '/login?redirect=/carrinho';
            }

            if (document.querySelectorAll('.cart-item').length === 0) {
                return showNotification('Seu carrinho está vazio!', 'error');
            }

            showNotification('Redirecionando...', 'info');
        });
    }

    // Inicia carregamento
    loadCartItems();
});
