package io.github.brunoeugeniodev.marketplace;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NaLojaTemApplicationTests {

	@Test
	void contextLoads() {
	}

}
